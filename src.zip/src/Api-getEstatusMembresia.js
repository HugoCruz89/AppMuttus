import PathServer from './const/PathServer';

function getEstatusMembresia(rfc) {
  return fetch(PathServer.url + 'EstatusAsociado/' + rfc)
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export {getEstatusMembresia};
