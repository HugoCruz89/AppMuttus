import React from 'react';
import {
  View,
  StyleSheet,
  Image,
  Platform,
  TouchableOpacity,
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import {responsiveHeight} from 'react-native-responsive-dimensions';
import {ifIphoneX} from 'react-native-iphone-x-helper';

const Header = (props) => (
  <View style={styles.container}>
    <TouchableOpacity onPress={() => props.home()}>
      <Icon name="chevron-left" color="black" size={25} />
    </TouchableOpacity>
    <Image style={styles.logo} source={require('../../images/logo2.png')} />
    <Icon name="search" color="white" size={25} />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    ...ifIphoneX(
      {
        height:
          Platform.OS === 'ios' ? responsiveHeight(9) : responsiveHeight(7),
        paddingTop: 20,
      },
      {
        height:
          Platform.OS === 'ios' ? responsiveHeight(7) : responsiveHeight(7),
        top: Platform.OS === 'ios' ? 0 : 0,
        paddingTop: Platform.OS === 'ios' ? 0 : 0,
      },
    ),

    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: Platform.OS === 'ios' ? 0 : 0,
    top: Platform.OS === 'ios' ? 10 : 0,
  },
  logo: {
    width: 135,
    height: 40,
  },
});

export default Header;
