import React, {Component} from 'react';
import {
  Dimensions,
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  Platform,
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/FontAwesome';
import {
  responsiveFontSize,
  responsiveHeight,
  responsiveWidth
} from 'react-native-responsive-dimensions';

import AsyncStorage from '@react-native-async-storage/async-storage';
import {getFarmacia} from '../../Api-Client-Farmacia';
import Communications from 'react-native-communications';
const {width, heigth} = Dimensions.get('window');

const USR_STG = 'rfc';
const NOMBRE_STG = 'nombre';
const SaldoMembresia = 'saldoMembresia';
const MEMBRESIA = 'TipoMembresia';

export default class Menu extends Component {
  constructor(props) {
    super(props);
    this.getDataFarmacia();
    this.getDatos();
    this.state = {
      NombreUsuario: 'Mike',
      tipoMembresia: '0',
      bandera: false,
      Token: '',
    };
  }

  async getDatos() {
    let nombre = await AsyncStorage.getItem(NOMBRE_STG);
    let tMembresia = await AsyncStorage.getItem(MEMBRESIA);

    this.state.NombreUsuario = nombre;
    this.state.tipoMembresia = tMembresia;
  }
  async getDataFarmacia() {
    let rfc = await AsyncStorage.getItem(USR_STG);
    getFarmacia(rfc).then((data) => {
      const {ApplicaFarmacia, Token} = data;
     
      this.setState({
        bandera: ApplicaFarmacia,
        Token,
      });
    });
  }

  async logout() {
    await AsyncStorage.removeItem(USR_STG);
    await AsyncStorage.removeItem(SaldoMembresia);
    Actions.login();
  }

  notificaciones() {
    Actions.notificaciones();
  }

  llamaVistaCredencial() {
    Actions.miCredencial();
  }

  llamaVistaBeneficiarios() {
    Actions.beneficiarioView();
  }

  llamaVistaPDF() {
    Actions.PDFView();
  }
  llamaVistaPDFRecobra1() {
    Actions.PDFViewRecobra1();
  }

  render() {
    return (
      <View style={styles.menu}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatarImage}>
            <Icon name="user-o" color="black" size={25} style={styles.avatar} />
            <Text style={styles.text} onPress={this.logout}>
              {this.state.NombreUsuario}
            </Text>
            <TouchableOpacity
              onPress={this.logout}
              style={styles.avatarContainer}>
              <Icon name="sign-out" color="black" size={25} />
            </TouchableOpacity>
          </View>
        </View>
        <TouchableOpacity
          onPress={this.llamaVistaCredencial}
          style={styles.avatarContainer}>
          <View style={styles.avatarImage}>
            <Text style={styles.text}>Mi Credencial</Text>
          </View>
          <Icon name="id-card" color="black" size={25} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={this.llamaVistaBeneficiarios}
          style={styles.avatarContainer}>
          <View style={styles.avatarImage}>
            {this.state.tipoMembresia == '1' ? (
              <Text style={styles.text}>Dependientes</Text>
            ) : (
              <Text style={styles.text}>Dependientes</Text>
            )}
          </View>
          <Icon name="users" color="black" size={25} />
        </TouchableOpacity>
        {this.state.tipoMembresia == '1' ? (
          <TouchableOpacity
            onPress={this.llamaVistaPDF}
            style={styles.avatarContainer}>
            <View style={styles.avatarImage}>
              <Text style={styles.text}>
                Condiciones Generales{'\n'} de la Póliza
              </Text>
            </View>
            <Icon name="file-text" color="black" size={25} />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onPress={this.llamaVistaPDFRecobra1}
            style={styles.avatarContainer}>
            <View style={styles.avatarImage}>
              <Text style={styles.text}>
                Condiciones Generales{'\n'}Mutuus Recobra
              </Text>
            </View>
            <Icon name="file-text" color="black" size={25} />
          </TouchableOpacity>
        )}
        {this.state.bandera ? (
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => Communications.web(`${this.state.Token}`)}>
            <View style={styles.FarmaciaContainer}>
              <Image
                style={styles.logo}
                source={require('../../images/logoFarmacia2.png')}
              />
              
            </View>
          </TouchableOpacity>
        ) : null}
        <ScrollView style={styles.scrollContainer}></ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  menu: {
    flex: 1,
    backgroundColor: 'white',
    width: width,
    height: heigth,
  },
  avatarContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: width / 2 + 50,
    borderColor: '#fff',
    borderBottomWidth: 3,
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  avatar: {
    width: 25,
    height: 25,
    margin: 10,
  },
  avatarImage: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  text: {
    fontSize: responsiveFontSize(2),
    color: '#444343',
  },
  FarmaciaContainer: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    backgroundColor: 'transparent',
  },
  logo: {
    top: '15%',
    left:10,
    width: responsiveWidth(60),
    height: responsiveHeight(12.5),
    resizeMode: 'stretch',
  },
});
