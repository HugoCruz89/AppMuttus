import React, {Component} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Platform,
  Alert,
  BackAndroid,
  ImageBackground,
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import SideMenu from 'react-native-side-menu';
import Menu from './Menu';
import Header from './Header';
import call from 'react-native-phone-call';
import Communications from 'react-native-communications';
import {
  responsiveHeight,
  responsiveFontSize,
} from 'react-native-responsive-dimensions';
import {PermissionsAndroid} from 'react-native';
import {getEstatusMembresia} from '../../Api-getEstatusMembresia';
import {showLoading, hideLoading} from 'react-native-notifyer';

import AsyncStorage from '@react-native-async-storage/async-storage';
const USR_STG = 'rfc';
const MEMBRESIA = 'TipoMembresia';

export default class Home extends Component {
  constructor(props) {
    super(props);
    this.getDatos();
    this.requestGPS();
    this.requestCamera();
    this.requestExternalStorage();

    this.state = {
      isOpen: false,
      tipoMembresia: '0',
    };
  }

  async getDatos() {
    var tMembresia = await AsyncStorage.getItem(MEMBRESIA);
    this.setState({
      tipoMembresia: tMembresia,
    });
  }
  componentDidMount() {
    this.TraigoEstatusMembresia();
  }

  async requestGPS() {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Permiso para acceder a GPS',
            message:
              'Es necesario activar el GPS para poder mandar ' +
              'tu ubicacion de la urgencia.',
            buttonNeutral: 'Preguntar mas tarde',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          },
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        } else {
          console.warn('Camera permission denied');
        }
      } catch (err) {
        console.warn(err);
      }
    }
  }

  async requestCamera() {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA,
          {
            title: 'Permiso para acceder a GPS',
            message:
              'Es necesario activar el GPS para poder mandar ' +
              'tu unicacion de la urgencia.',
            buttonNeutral: 'Preguntar mas tarde',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          },
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        } else {
        }
      } catch (err) {
        console.warn(err);
      }
    }
  }
  async requestExternalStorage() {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
          {
            title: 'Permiso para acceder a GPS',
            message:
              'Es necesario activar el GPS para poder mandar ' +
              'tu unicacion de la urgencia.',
            buttonNeutral: 'Preguntar mas tarde',
            buttonNegative: 'Cancel',
            buttonPositive: 'OK',
          },
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        } else {
        }
      } catch (err) {}
    }
  }
  async TraigoEstatusMembresia() {
    showLoading();
    let rfc = await AsyncStorage.getItem(USR_STG);
    getEstatusMembresia(rfc)
      .then((data) => {
        hideLoading();
        if (String(data) == 'Cuenta Activa ') {
        } else if (String(data) == 'Cuenta Suspendida') {
          Alert.alert(
            data,
            'Tu cuenta ha sido suspendia',
            [{text: 'OK', onPress: () => this.onDeleteBTN}],
            {cancelable: false},
          );
          this.logout();
        } else if (data == undefined) {
          Alert.alert(
            'Error de Red',
            data,
            [{text: 'OK', onPress: () => this.onDeleteBTN}],
            {cancelable: false},
          );
          this.logout();
        } else {
          Alert.alert(
            data,
            'Tu cuenta ha sido dada de baja',
            [{text: 'OK', onPress: () => this.onDeleteBTN}],
            {cancelable: false},
          );
          this.logout();
        }
      })
      .catch((data) => {
        Alert.alert(
          'Error de Red',
          data,
          [{text: 'OK', onPress: () => this.onDeleteBTN}],
          {cancelable: false},
        );
        this.logout();
      });
  }

  async logout() {
    if (Platform.OS === 'ios') {
      await AsyncStorage.removeItem(USR_STG);
      Actions.login();
    } else {
      await AsyncStorage.removeItem(USR_STG);
      BackAndroid.exitApp();
    }
  }

  toggle() {
    this.setState({
      isOpen: !this.state.isOpen,
    });
  }

  updateMenu(isOpen) {
    this.setState({isOpen});
  }

  llamaVistaReportaEvento() {
    Actions.reportaEvento();
  }
  llamaVistaUrgencia() {
    Actions.urgencia();
  }
  llamaVistaCuenta() {
    Actions.miCuenta();
  }
  llamaVistaPDFRecobra2() {
    Actions.PDFViewRecobra2();
  }
  llamaVistaContacto() {
    Actions.contacto();
  }
  llamaVistaCredencial() {
    Actions.miCredencial();
  }

  render() {
    const args = {
      number: '5585258800', // String value with the number to call
      prompt: true, // Optional boolean property. Determines if the user should be prompt prior to the call
    };
    return (
      <View style={styles.PrincipalContainer}>
        <SideMenu
          menu={<Menu />}
          isOpen={this.state.isOpen}
          onChange={(isOpen) => this.updateMenu(isOpen)}>
          <ImageBackground
            source={require('../../images/FondoMenu.jpg')}
            style={styles.BackgroundImage}>
            <Header
              navigation={this.props.navigation}
              toggle={this.toggle.bind(this)}
            />
            <View style={styles.FirstBlock} />
            <View style={styles.ContainerButtons}>
              <TouchableOpacity onPress={this.llamaVistaUrgencia}>
                <View style={styles.cardVerde}>
                  <Text style={styles.title}>Urgencia</Text>
                  <Image
                    style={styles.ImageUrgencia}
                    source={require('../../images/urgencia.png')}
                  />
                </View>
              </TouchableOpacity>
              <TouchableOpacity onPress={this.llamaVistaReportaEvento}>
                <View style={styles.cardAzul}>
                  <Text style={styles.title}>Reportar Evento</Text>
                  <Image
                    style={styles.ImageReportar}
                    source={require('../../images/reportar.png')}
                  />
                </View>
              </TouchableOpacity>
              {Platform.OS === 'ios' ? (
                <TouchableOpacity
                  onPress={() =>
                    Communications.web(
                      'https://apps.apple.com/mx/app/mutuus-servicios/id1500537106',
                    )
                  }>
                  <View style={styles.cardVerde}>
                    <Text style={styles.title}>Otros Servicios</Text>
                    <Image
                      style={styles.ImageServicios}
                      source={require('../../images/servicios.png')}
                    />
                  </View>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() =>
                    Communications.web(
                      'https://play.google.com/store/apps/details?id=com.mutuus.integra',
                    )
                  }>
                  <View style={styles.cardVerde}>
                    <Text style={styles.title}>Otros Servicios</Text>
                    <Image
                      style={styles.ImageServicios}
                      source={require('../../images/servicios.png')}
                    />
                  </View>
                </TouchableOpacity>
              )}

              <TouchableOpacity
                onPress={() => call(args).catch(console.warn.error)}>
                <View style={styles.cardAzul}>
                  <Text style={styles.title}>Concierge de Salud</Text>
                  <Image
                    style={styles.ImageConsierje}
                    source={require('../../images/conserje_ok.png')}
                  />
                </View>
              </TouchableOpacity>
              {this.state.tipoMembresia == '1' ? (
                <TouchableOpacity onPress={this.llamaVistaCuenta}>
                  <View style={styles.cardVerde}>
                    <Text style={styles.title}>Mi Cuenta</Text>
                    <Image
                      style={styles.ImagePersona}
                      source={require('../../images/persona.png')}
                    />
                  </View>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity onPress={this.llamaVistaPDFRecobra2}>
                  <View style={styles.cardVerde}>
                    <Text style={styles.title}>Coberturas</Text>
                    <Image
                      style={styles.ImagePersona}
                      source={require('../../images/persona.png')}
                    />
                  </View>
                </TouchableOpacity>
              )}
            </View>
          </ImageBackground>
        </SideMenu>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  PrincipalContainer: {flex: 1},
  BackgroundImage: {
    width: '100%',
    height: '100%',
  },
  FirstBlock: {
    height: responsiveHeight(15),
  },
  ContainerButtons: {
    height: responsiveHeight(85),
    flexDirection: 'column',
  },
  ImageUrgencia: {
    width: 58,
    height: 50,
    right: 20,
    top: Platform.OS === 'ios' ? 20 : 13,
  },
  ImageReportar: {
    width: 58,
    height: 57,
    right: 10,
    top: Platform.OS === 'ios' ? 20 : 11,
  },
  ImageServicios: {
    width: 44,
    height: 56,
    right: 20,
    top: Platform.OS === 'ios' ? 20 : 13,
  },
  ImageConsierje: {
    width: 45,
    height: 50,
    right: 15,
    top: Platform.OS === 'ios' ? 20 : 13,
  },
  ImagePersona: {
    width: 45,
    height: 50,
    right: 15,
    top: Platform.OS === 'ios' ? 20 : 13,
  },
  logos: {
    width: 45,
    height: 50,
    right: 20,
    top: 20,
  },
  title: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 30,
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(2.3) : responsiveFontSize(2.5),
    textAlign: 'left',
    left: 20,
    fontWeight: '700',
  },
  cardVerde: {
    width: '96%',
    height: responsiveHeight(13),
    backgroundColor: 'rgba(174,212,58,0.6)',
    marginVertical: 8,
    marginHorizontal: 6,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardAzul: {
    width: '96%',
    height: responsiveHeight(13),
    backgroundColor: 'rgba(24,59,145,0.8)',
    marginVertical: 8,
    marginHorizontal: 6,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
