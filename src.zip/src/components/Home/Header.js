import React from 'react';
import {
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  Platform,
} from 'react-native';

import Icon from 'react-native-vector-icons/FontAwesome';
import {responsiveHeight} from 'react-native-responsive-dimensions';
import {ifIphoneX} from 'react-native-iphone-x-helper';

const Header = (props) => (
  <View style={styles.container}>
    <View style={styles.headerContainer}>
      <TouchableOpacity onPress={() => props.toggle()}>
        <Icon name="bars" color="white" size={25} />
      </TouchableOpacity>
    </View>
    <View style={{alignItems: 'center', width: '70%'}}>
      <Image
        style={styles.logo}
        source={require('../../images/Mutuus_Blanco.png')}
      />
    </View>
  </View>
);

const styles = StyleSheet.create({
  headerContainer: {
    alignItems: 'center',
    width: '8%',
    ...ifIphoneX(
      {
        top: 20,
      },
      {
        top: Platform.OS === 'ios' ? 15 : 5,
      },
    ),
  },
  container: {
    flexDirection: 'row',
    ...ifIphoneX(
      {
        height:
          Platform.OS === 'ios' ? responsiveHeight(9) : responsiveHeight(7),
        paddingTop: 17,
      },
      {
        height:
          Platform.OS === 'ios' ? responsiveHeight(7) : responsiveHeight(7),
        top: Platform.OS === 'ios' ? 20 : 15,
        paddingTop: Platform.OS === 'ios' ? 0 : 0,
      },
    ),
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'transparent',
    paddingHorizontal: 20,
    position: 'absolute',
    zIndex: 1,
  },
  logo: {
    width: 185,
    height: 60,
    top: Platform.OS === 'ios' ? 20 : 0,
  },
});

export default Header;
