import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  View,
  TextInput,
  TouchableOpacity,
  Text,
  Image,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import {getDatosLogin} from '../../Api-client-Login';
import {
  responsiveFontSize,
  responsiveHeight,
} from 'react-native-responsive-dimensions';
import {showLoading, hideLoading} from 'react-native-notifyer';
import {ifIphoneX} from 'react-native-iphone-x-helper';
import Communications from 'react-native-communications';

import AsyncStorage from '@react-native-async-storage/async-storage';
const USR_STG = 'rfc';
const NOMBRE_STG = 'nombre';
const ApellMat_STG = 'apellMat';
const ApellPat_STG = 'apellPat';
const FECHA_STG = 'fechaNacimiento';
const SOCIO = 'numeroSocio';
const VIGENCIA = 'vigencia';
const MEMBRESIA = 'TipoMembresia';

const SaldoMembresia = 'saldoMembresia';

const LoginForm = (props) => {
  const [mensaje, setMensaje] = useState('');
  const [usuario, setUsuario] = useState('');
  const [contrasena, setContrasena] = useState('');

  const GetDatos = async () => {
    try {
      const rfc = await AsyncStorage.getItem(USR_STG);
      if (rfc !== null) {
        home();
      }
    } catch {}
  };
  useEffect(() => {
    GetDatos();
  });

  const almacenaUsuario = async (datos) => {
    if (datos != null) {
      hideLoading();
      try {
        await AsyncStorage.setItem(USR_STG, datos.Rfc);
        await AsyncStorage.setItem(NOMBRE_STG, datos.Nombre);
        await AsyncStorage.setItem(ApellMat_STG, datos.ApellidoMaterno);
        await AsyncStorage.setItem(ApellPat_STG, datos.ApellidoPaterno);
        await AsyncStorage.setItem(FECHA_STG, datos.FechaNacimiento);
        await AsyncStorage.setItem(SOCIO, String(datos.FolioAsociado));
        await AsyncStorage.setItem(FECHA_STG, datos.FechaNacimiento);
        await AsyncStorage.setItem(MEMBRESIA, datos.MembresiaSuscripcion);
        await AsyncStorage.getItem(MEMBRESIA);
        await AsyncStorage.setItem(VIGENCIA, datos.fechaVigencia);
        if (String(datos.tipoMembresia) === '1') {
          await AsyncStorage.setItem(SaldoMembresia, '1000000');
        } else if (String(datos.tipoMembresia) === '2') {
          await AsyncStorage.setItem(SaldoMembresia, '2000000');
        } else if (String(datos.tipoMembresia) === '5') {
          await AsyncStorage.setItem(SaldoMembresia, '5000000');
        }
        GetDatos();
      } catch (error) {}
    } else {
      hideLoading();
      setMensaje('Usuario o contraseña incorrecta');
    }
  };

  const home = () => {
    Actions.home();
  };
  const llamaVistaAvisoPrivacidad = () => {
    Actions.avisoPrivacidad();
  };

  const onChangeUsuario = (value) => {
    setUsuario(value);
    setMensaje('');
  };

  const onChangePassword = (value) => {
    setContrasena(value);
  };

  const login = () => {
    showLoading();
    getDatosLogin(usuario, contrasena).then((data) => {
      almacenaUsuario(data);
    });
  };

  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss();
      }}>
      <View style={styles.PrincipalContainer}>
        <Image
          source={require('../../images/LoginNuevo.jpg')}
          style={styles.backgroundImage}
        />
        <View style={styles.logoContainer}>
          <Image
            style={styles.logo}
            source={require('../../images/Mutuus_Blanco.png')}
          />
        </View>
        <View style={styles.contenedor}>
          <TextInput
            style={styles.input}
            value={usuario}
            onChangeText={onChangeUsuario}
            underlineColorAndroid="transparent"
            placeholder="Usuario"
            returnKeyType="next"
            placeholderTextColor="rgba(255,255,255,1)"
          />
          <TextInput
            style={styles.input}
            value={contrasena}
            onChangeText={onChangePassword}
            underlineColorAndroid="transparent"
            placeholder="Contraseña"
            secureTextEntry
            returnKeyType="go"
            placeholderTextColor="rgba(255,255,255,1)"
          />
          <Text style={styles.errorLabel}>{mensaje}</Text>
          <TouchableOpacity
            onPress={() => login()}
            style={styles.buttonContainer}>
            <Text style={styles.buttonText}>Ingresar</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => Communications.web('https://www.psmutuus.com.mx/')}
            style={styles.buttonContainerRegistro}>
            <Text style={styles.buttonTextRegistrate}>
              Compra tu membresia de salud
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={llamaVistaAvisoPrivacidad}
            style={styles.buttonContainerAvisoPrivacidad}>
            <Text style={styles.buttonTextAvisoPrivacidad}>
              Aviso de Privacidad
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};
const styles = StyleSheet.create({
  PrincipalContainer: {
    flex: 1,
  },
  contenedor: {
    position: 'absolute',
    width: '100%',
    height: '80%',
    top: '40%',
    borderRadius: 25,
    alignItems: 'center',
    backgroundColor: 'transparent',
  },
  scroll: {
    width: '100%',
    height: '100%',
    top: '2%',
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    width: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titulo: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: responsiveFontSize(4),
    paddingBottom: '10%',
  },
  textoContainerTitulo: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '10%',
  },

  input: {
    alignSelf: 'center',
    padding: 0,
    height: 45,
    backgroundColor: 'rgba(174,212,58,1.0)',
    marginBottom: 20,
    color: 'white',
    borderRadius: 8,
    width: '80%',
    textAlign: 'center',
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.3) : responsiveFontSize(2),
  },
  Entrada: {
    width: 300,
    height: 40,
    borderColor: 'gray',
    backgroundColor: 'rgba(255,255,255,0.8)',
    borderWidth: 1,
    marginTop: 10,
    paddingHorizontal: 30,
  },
  buttonContainer: {
    backgroundColor: '#AED43A',
    paddingVertical: 15,
    padding: 0,
    borderRadius: 8,
    width: '50%',
    height: 45,
    alignSelf: 'center',
  },
  buttonContainerAvisoPrivacidad: {
    backgroundColor: 'transparent',
    marginBottom: 20,
    borderRadius: 8,
    width: '100%',
    marginTop: Platform.OS === 'ios' ? '10%' : '8%',
    height: 45,
    alignSelf: 'center',
  },
  buttonContainerRegistro: {
    top: Platform.OS === 'ios' ? '10%' : '10%',
    backgroundColor: 'transparent',
    marginBottom: Platform.OS === 'ios' ? 20 : 0,
    borderRadius: 8,
    width: '100%',
    height: 45,
    alignSelf: 'center',
  },
  buttonText: {
    padding: 0,
    textAlign: 'center',
    color: '#FFF',
    height: 30,
    borderRadius: 25,
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.3) : responsiveFontSize(2),
  },
  buttonTextAvisoPrivacidad: {
    textAlign: 'center',
    color: '#ffffff',
    fontWeight: '900',
  },
  buttonTextRegistrate: {
    textAlign: 'center',
    color: 'white',
    fontWeight: '900',
  },
  errorLabel: {
    color: '#FF0000',
    marginBottom: 15,
    textAlign: 'center',
    fontWeight: '900',
  },
  logo: {
    ...ifIphoneX(
      {
        bottom: '35%',
        width: '80%',
        height: 80,
      },
      {
        bottom: '35%',
        width: '80%',
        height: Platform.OS === 'ios' ? responsiveHeight(14) : 65,
      },
    ),
  },
  logoContainer: {
    ...ifIphoneX(
      {
        position: 'absolute',
        alignItems: 'center',
        width: '80%',
        height: '20%',
        top: '20%',
        left: '10%',
      },
      {
        position: 'absolute',
        alignItems: 'center',
        width: '80%',
        height: '20%',
        top: '20%',
        left: '10%',
      },
    ),
  },
});
export default LoginForm;
