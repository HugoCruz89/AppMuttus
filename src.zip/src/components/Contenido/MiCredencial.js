import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  TouchableOpacity,
  Platform,
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
import {responsiveFontSize} from 'react-native-responsive-dimensions';
import ImagePicker from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/FontAwesome';
import AsyncStorage from '@react-native-async-storage/async-storage';
const NOMBRE_STG = 'nombre';
const FECHA_STG = 'fechaNacimiento';
const SOCIO = 'numeroSocio';
const VIGENCIA = 'vigencia';
const IMG_PATH = 'IMAGE';
const ApellMat_STG = 'apellMat';
const ApellPat_STG = 'apellPat';

export default class Credencial extends Component {
  home() {
    Actions.home();
  }

  constructor(props) {
    super(props);
    this.getImagen();
    this.getDatos();
    this.state = {
      NombreUsuario: 'Mike',
      fechaNacimiento: '',
      numeroSocio: '',
      vigencia: '',
      imagePath: '',
      imageHeight: '',
      imageWidth: '',
      apellidoMaterno: '',
      apellidoPaterno: '',
    };
  }

  async getDatos() {
    let NombreUsuario = await AsyncStorage.getItem(NOMBRE_STG);
    let fechaNacimiento = await AsyncStorage.getItem(FECHA_STG);
    let numeroSocio = await AsyncStorage.getItem(SOCIO);
    let vigencia = await AsyncStorage.getItem(VIGENCIA);
    let apellidoMaterno = await AsyncStorage.getItem(ApellMat_STG);
    let apellidoPaterno = await AsyncStorage.getItem(ApellPat_STG);
    this.setState({
      NombreUsuario,
      fechaNacimiento,
      numeroSocio,
      vigencia,
      apellidoMaterno,
      apellidoPaterno,
    });
  }

  openImagePicker() {
    const options = {
      title: 'Selecciona tu imagen o escogela de tu biblioteca',
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };
    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        console.warn('user cancel image picker');
      } else if (response.error) {
        console.warn('Error', response.error);
      } else if (response.customButton) {
        console.warn('user taped custom button', response.customButton);
      } else {
        this.almacenaImagen(response.uri);
      }
    });
  }

  async almacenaImagen(datos) {
    if (datos != null) {
      try {
        await AsyncStorage.setItem(IMG_PATH, datos);
        this.getImagen();
      } catch (error) {}
    }
  }

  async getImagen() {
    let imagen = await AsyncStorage.getItem(IMG_PATH);
    this.setState({
      imagePath: imagen,
    });
  }

  render() {
    const agregaEnfermedad = <Icon name="plus" size={15} color="#92D050" />;
    return (
      <View style={{flex: 1}}>
        <HeaderContenido home={this.home.bind(this)} />
        <Image
          source={require('../../images/fondoDatos.jpg')}
          style={styles.backgroundImage}
        />
        <View style={styles.textoContainerTitulo}>
          <Text style={styles.Titulo}>Mi Credencial</Text>
        </View>
        <View style={styles.contenedor}>
          <Image
            style={styles.logo}
            source={require('../../images/logo2.png')}
          />
          {this.state.imagePath ? (
            <Image style={styles.Image} source={{uri: this.state.imagePath}} />
          ) : null}
        </View>
        <View style={styles.textoContainer}>
          <TouchableOpacity onPress={this.openImagePicker.bind(this)}>
            <Text style={{fontSize: responsiveFontSize(1.5)}}>
              {agregaEnfermedad} Ingresa-Actualiza Tu Foto
            </Text>
          </TouchableOpacity>
          <View style={styles.row}>
            <View style={styles.column}>
              <Text style={styles.datosPersonales}>Nombre:</Text>
              <Text style={styles.DatosCredencial}>
                {this.state.NombreUsuario} {this.state.apellidoPaterno}{' '}
                {this.state.apellidoMaterno}
              </Text>
            </View>

            <View style={styles.column}>
              <Text style={styles.datosPersonales}>Socio MUTUUS No.</Text>
              <Text style={styles.DatosCredencial}>
                {this.state.numeroSocio}
              </Text>
            </View>

            <View style={styles.column}>
              <Text style={styles.datosPersonales}>Edad</Text>
              <Text style={styles.DatosCredencial}>
                {this.state.fechaNacimiento} años
              </Text>
            </View>

            <View style={styles.column}>
              <Text style={styles.datosPersonales}>Vigencia</Text>
              <Text style={styles.DatosCredencial}> {this.state.vigencia}</Text>
              <Image
                style={styles.qr}
                source={require('../../images/qr2.jpeg')}
              />
              <View style={styles.ContainerLogos}>
                <Image
                  style={styles.Logo_Das}
                  source={require('../../images/Logo_DAS.png')}
                />
                <Image
                  style={styles.Logo_GDS}
                  source={require('../../images/Logo_GDS.png')}
                />
                <Image
                  style={styles.Logo_Kalan}
                  source={require('../../images/kalaan_1.png')}
                />
                <Image
                  style={styles.LogoIntegra}
                  source={require('../../images/integra_salud.png')}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  Image: {
    width: 100,
    height: 100,
    top: '10%',
    borderRadius: 50,
  },
  ContainerLogos: {
    flexDirection: 'row',
    width: '100%',
    left: 8,
  },
  Logo_Das: {
    width: 62,
    height: 33,
    top: 35,
    right: 25,
  },
  Logo_GDS: {
    width: 70,
    height: 40,
    top: 35,
    right: 20,
  },
  Logo_Kalan: {
    width: 40,
    height: 35,
    top: 35,
    right: 10,
  },
  LogoIntegra: {
    width: 45,
    height: 35,
    top: 35,
    left: 10,
  },
  row: {
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 0,
    paddingHorizontal: 1,
    borderRadius: 2,
    top: 5,
  },
  logo: {
    width: 150,
    height: 45,
    bottom: '18%',
    zIndex: 1,
    position: 'absolute',
    top: 15,
  },
  qr: {
    width: 60,
    height: 60,
    top: '10%',
    marginHorizontal: '15%',
  },
  logos: {
    width: 100,
    height: 54,
    top: '5%',
    marginHorizontal: '15%',
  },
  Titulo: {
    backgroundColor: 'transparent',
    color: '#92D050',
    marginTop: -4,
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.3) : responsiveFontSize(3),
  },
  contenedor: {
    position: 'absolute',
    width: '90%',
    height: '80%',
    bottom: '3%',
    marginLeft: '5%',
    backgroundColor: 'white',
    borderRadius: 15,
    alignItems: 'center',
    zIndex: 0,
  },
  column: {
    flexDirection: 'column',
    alignItems: 'center',
    paddingVertical: 0,
    marginBottom: 6,
    marginHorizontal: 5,
    paddingHorizontal: 5,
    top: -4,
  },
  datosPersonales: {
    backgroundColor: 'transparent',
    color: 'black',
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.7) : responsiveFontSize(2),
  },
  DatosCredencial: {
    backgroundColor: 'transparent',
    color: 'black',
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.3) : responsiveFontSize(2),
    top: 2,
    marginBottom: 5,
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    width: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textoContainerTitulo: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '10%',
    paddingTop: Platform.OS === 'ios' ? 10 : 0,
  },
  textoContainer: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '40%',
    paddingTop: 10,
  },
});
