import React from 'react';
import {Text, View, StyleSheet, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
const agregaEnfermedad = <Icon name="plus" size={20} color="white" />;

const NavBarDiagnostico = (props) => {
  return (
    <View style={styles.content}>
      <TouchableOpacity
        style={styles.containerButton}
        onPress={props.openModal}>
        <Text style={styles.textCenter}>
          {agregaEnfermedad} Agregar Diagnóstico
        </Text>
      </TouchableOpacity>
      <Text style={styles.textCenter} />
    </View>
  );
};

const styles = StyleSheet.create({
  content: {
    paddingTop: 20,
    paddingBottom: 10,
    backgroundColor: 'transparent',
    flexDirection: 'row',
    marginHorizontal: 20,
  },
  containerButton: {
    position: 'absolute',
    top: 5,
    zIndex: 1,
    left: 12,
  },
  textCenter: {
    flex: 1,
    textAlign: 'center',
    fontWeight: 'bold',
    color: 'white',
  },
});
export default NavBarDiagnostico;
