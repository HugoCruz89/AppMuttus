import React from 'react';
import {Text, View, StyleSheet, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {string, func, number} from 'prop-types';
const deleteRow = <Icon name="times" size={20} color="red" />;

const ItemsDiagnostico = (props) => {
  return (
    <View style={styles.principalContainer}>
      <View style={styles.row}>
        <View style={styles.column}>
          <Text style={styles.titulo2}>Diagnostico</Text>
          <Text style={styles.Informacion}>{props.diagnostico}</Text>
        </View>
        <TouchableOpacity
          style={{marginTop: 20}}
          onPress={props.handleRemoveItem.bind(this, props.id)}>
          {deleteRow}
        </TouchableOpacity>
      </View>
    </View>
  );
};
ItemsDiagnostico.prototype = {
  id: number,
  handleRemoveItem: func,
  diagnostico: string,
};

const styles = StyleSheet.create({
  icon: {
    marginTop: 20,
  },
  principalContainer: {
    flex: 1,
    alignItems: 'center',
  },
  column: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    backgroundColor: 'transparent',
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
  },
  row: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    marginBottom: 5,
    paddingHorizontal: 5,
    borderRadius: 7,
    width: '95%',
  },
  titulo2: {
    backgroundColor: 'transparent',
    color: '#98D17B',
    fontSize: 15,
  },
  Informacion: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 0,
    fontSize: 15,
  },
});
export default ItemsDiagnostico;
