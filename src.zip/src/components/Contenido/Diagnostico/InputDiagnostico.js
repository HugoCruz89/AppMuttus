import React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableHighlight,
  TouchableWithoutFeedback,
  Keyboard,
  TouchableOpacity,
} from 'react-native';

import Modal from 'react-native-modal';
import Icon from 'react-native-vector-icons/FontAwesome';

const InputDiagnostico = (props) => {
  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss();
      }}>
      <View style={styles.container}>
        <Modal
          style={styles.modalTop}
          isVisible={props.isVisible}
          animationIn={'slideInLeft'}
          animationOut={'slideOutRight'}>
          <View style={styles.modalContent}>
            <View style={{marginLeft: '95%', marginBottom: 10}}>
              <TouchableOpacity
                style={{width: 30}}
                onPress={props.onCloseModal}>
                <Icon name="times" size={20} color="black" />
              </TouchableOpacity>
            </View>

            <TextInput
              underlineColorAndroid="transparent"
              value={props.diagnostico}
              placeholder="Diagnóstico"
              placeholderTextColor="rgba(10,10,10,0.5)"
              style={styles.input}
              onChangeText={(diagnostico) => props.onChangeTitle(diagnostico)}
            />
            <TouchableHighlight
              style={styles.button}
              onPress={props.onHandleItems}>
              <Text style={styles.buttonText}>Guardar</Text>
            </TouchableHighlight>
          </View>
        </Modal>
      </View>
    </TouchableWithoutFeedback>
  );
};

const styles = StyleSheet.create({
  modalTop: {
    justifyContent: 'flex-start',
    marginTop: 50,
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 9,
  },
  input: {
    marginBottom: 5,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 6,
  },
  button: {
    backgroundColor: '#98D17B',
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 5,
    borderRadius: 6,
  },
  buttonText: {
    textAlign: 'center',
    color: 'white',
  },
});
export default InputDiagnostico;
