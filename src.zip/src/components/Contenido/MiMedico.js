import React, {Component} from 'react';
import {StyleSheet, View, Image, Text} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
export default class MiMedico extends Component {
  home() {
    Actions.home();
  }

  render() {
    return (
      <View style={{flex: 1}}>
        <HeaderContenido home={this.home.bind(this)} />
        <Image
          source={require('../../images/fondoDatos.jpg')}
          style={styles.backgroundImage}
        />

        <View style={styles.textoContainerTitulo}>
          <Text style={styles.titulo}>Mi Cuenta</Text>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    width: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: 30,
  },
  titulo: {
    backgroundColor: 'transparent',
    color: '#2995C3',
    marginTop: 10,
    fontSize: 35,
  },
  titulo2: {
    backgroundColor: 'transparent',
    color: '#98D17B',
    marginTop: 18,
    fontSize: 20,
  },
  Informacion: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 0,
    fontSize: 20,
  },
  textoContainerTitulo: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '10%',
  },
  textoContainer: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '25%',
  },

  textoContainerTitulo2: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '50%',
  },
  textoContainer2: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '50%',
  },
});
