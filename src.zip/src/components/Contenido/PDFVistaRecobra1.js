import React from 'react';
import {View} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
import PDFView from 'react-native-view-pdf';

const resources = {
  url:
    'https://mutuuspro.blob.core.windows.net/imagenes/Condiciones_Generales_Recupera_Colectivo.pdf',
};

const PDFVistaRecobra1 = () => {
  const home = () => {
    Actions.home();
  };

  const resourceType = 'url';
  return (
    <View style={{flex: 1}}>
      <HeaderContenido home={home.bind(this)} />
      <View style={{flex: 1}}>
        <PDFView
          fadeInDuration={250.0}
          style={{flex: 1}}
          resource={resources[resourceType]}
          resourceType={resourceType}
          onLoad={() =>
            console.warn('PDF rendered from ${resourceType}', resourceType)
          }
          onError={(error) => console.warn('Cannot render PDF', error)}
        />
      </View>
    </View>
  );
};
export default PDFVistaRecobra1;
