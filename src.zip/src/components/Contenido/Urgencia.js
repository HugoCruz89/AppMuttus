import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Image,
  Text,
  TouchableOpacity,
  Alert,
  Platform,
} from 'react-native';
import PathServer from '../../const/PathServer';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
import call from 'react-native-phone-call';
import {showLoading, hideLoading} from 'react-native-notifyer';
import Geolocation from '@react-native-community/geolocation';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Icon from 'react-native-vector-icons/FontAwesome';
import {
  responsiveHeight,
  responsiveWidth,
  responsiveFontSize,
} from 'react-native-responsive-dimensions';
const USR_STG = 'rfc';
const args = {
  number: '8009530387', // String value with the number to call
  prompt: true, // Optional boolean property. Determines if the user should be prompt prior to the call
};
const Cruz = <Icon name="plus" color="white" size={80} />;
const Phone = <Icon name="phone" color="white" size={80} />;

export default class Urgencia extends Component {
  constructor(props) {
    super(props);
    this.getGPS();
    this.getDatos();
    this.state = {
      latitude: null,
      longitude: null,
      error: null,
      rfc: '',
    };
  }

  async getGPS() {
    Geolocation.getCurrentPosition(
      (position) => {
        var latitud = position.coords.latitude;
        var longitud = position.coords.longitude;
        this.setState({
          latitude: latitud,
          longitude: longitud,
        });
      },
      (error) => console.log(error),
      {enableHighAccuracy: true, timeout: 40000, maximumAge: 0},
    );
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(USR_STG);
    this.setState({
      rfc: rfc,
    });
  }

  enviarUrgencia() {
    if (this.state.latitude != null) {
      showLoading();
      return fetch(PathServer.url + 'Urgencia/', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rfc: this.state.rfc,
          latitud: this.state.latitude,
          longitud: this.state.longitude,
        }),
      })
        .then((response) => {
          hideLoading();
          if (response.ok) {
            Alert.alert(
              'Envio urgencia',
              'La urgencia se mando correctamente',
              [{text: 'OK', onPress: () => console.log('OK Pressed')}],
              {cancelable: false},
            );
          } else {
            Alert.alert(
              'Error',
              'Ocurrio un error al enviar la urgencia, asegurate de haber otrogado los permisos de gps, y prueba de nuevo',
              [{text: 'OK', onPress: () => console.log('OK Pressed')}],
              {cancelable: false},
            );
          }
        })
        .catch((error) => {
          hideLoading();
          Alert.alert(
            'Error',
            '' + error,
            [{text: 'OK', onPress: () => console.log('OK Pressed')}],
            {cancelable: false},
          );
        });
    } else {
      Alert.alert(
        'Error de Ubicación',
        'Asegurate de tener encendido GPS',
        [{text: 'OK', onPress: () => console.log('OK Pressed')}],
        {cancelable: false},
      );
    }
  }

  home() {
    Actions.pop();
  }
  llamar() {
    call(args).catch(console.error);
  }
  render() {
    return (
      <>
        <HeaderContenido home={this.home.bind(this)} />
        <View style={styles.PrincipalContainer}>
          <Image
            source={require('../../images/fondoDatos.jpg')}
            style={styles.backgroundImage}
          />
          <View style={styles.contenedor}>
            <Text style={styles.title}>Teléfono Médico</Text>
            <TouchableOpacity onPress={() => this.llamar()}>
              <View style={styles.ContainerButton}>{Phone}</View>
            </TouchableOpacity>
          </View>
          <View style={styles.contenedor2}>
            <Text style={styles.title2}>Reporte de Urgencia</Text>
            <TouchableOpacity onPress={() => this.enviarUrgencia()}>
              <View style={styles.ContainerButtonUrgencia}>{Cruz}</View>
            </TouchableOpacity>
          </View>
        </View>
      </>
    );
  }
}
const styles = StyleSheet.create({
  ContainerButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 117,
    height: 117,
    borderRadius: 60,
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderColor: '#ACACAC',
    borderWidth: 2,
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  ContainerButtonUrgencia: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 117,
    height: 117,
    borderRadius: 60,
    backgroundColor: 'rgba(255, 28, 3, 0.8)',
    borderColor: '#ACACAC',
    borderWidth: 2,
    alignSelf: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  PrincipalContainer: {
    alignItems: 'center',
  },
  backgroundImage: {
    alignSelf: 'stretch',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
  },
  ImagePhone: {
    width: responsiveWidth(40),
    height: responsiveHeight(20),
    alignSelf: 'center',
  },

  contenedor: {
    position: 'absolute',
    width: responsiveWidth(90),
    height: responsiveHeight(35),
    top: responsiveHeight(5),
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderRadius: 25,
    alignItems: 'center',
  },
  contenedor2: {
    position: 'absolute',
    width: responsiveWidth(90),
    height: responsiveHeight(35),
    top: responsiveHeight(45),
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderRadius: 25,
    alignItems: 'center',
  },
  UbicacionImage: {
    width: responsiveWidth(40),
    height: responsiveHeight(23),
    alignSelf: 'center',
    bottom: responsiveHeight(6),
  },
  title2: {
    fontWeight: '800',
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: responsiveHeight(10),
    bottom: responsiveHeight(5),
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(2.5) : responsiveFontSize(3.2),
    textAlign: 'center',
  },
  title: {
    fontWeight: '800',
    textAlign: 'center',
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: responsiveHeight(11),
    bottom: responsiveHeight(5),
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(2.5) : responsiveFontSize(3.2),
  },
});
