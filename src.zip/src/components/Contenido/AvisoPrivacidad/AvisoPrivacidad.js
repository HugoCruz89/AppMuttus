import React from 'react';
import {StyleSheet, View, Image, Text, Platform} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../../Home/HeaderContenidoAvisoPrivacidad';
import {ifIphoneX} from 'react-native-iphone-x-helper';
import HTMLView from 'react-native-htmlview';
import {responsiveFontSize} from 'react-native-responsive-dimensions';

const AvisoPrivacidad = () => {
  const home = () => {
    Actions.pop();
  };
  const htmlContent = `<p>En cumplimiento a lo previsto en la Ley Federal de Protección de Datos Personales en posesión de particulares declara <b>PROSALUD MUTUUS, S.C. DE R.L. DE C.V.</b> ser una empresa legalmente constituida de conformidad con las leyes mexicanas, con domicilio en Palo Santo 6, Interior 2, Colonia Lomas Altas, Delegación Miguel Hidalgo, Ciudad de México, Código Postal 11950. Utilizará sus datos personales aquí recabados los cuales serán utilizados para fines de identificación en cualquier tipo de relación jurídica o de negocios que realices con nosotros. Así mismo se le informa que usted podrá consultar o acceder a nuestro aviso de privacidad integral a través de nuestra área encargada de la Protección de Datos Personales por medio del siguiente correo electrónico: info@psmutuus.com o bien en la página <a href="http://psmutuus.com/Home/AvisoPrivacidad"> http://psmutuus.com/Home/AvisoPrivacidad</a></p>`;
  return (
    <View style={{flex: 1}}>
      <HeaderContenido home={home.bind(this)} />
      <Image
        source={require('../../../images/fondoDatos.jpg')}
        style={styles.backgroundImage}
      />
      <View style={styles.container}>
        <View style={styles.textoContainerTitulo}>
          <Text style={styles.titulo}>Aviso de Privacidad</Text>
        </View>
      </View>
      <View style={styles.textoContainerAvisoPrivacidad}>
        <HTMLView value={htmlContent} stylesheet={styles} />
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  p: {
    fontWeight: '300',
    color: 'white',
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.6) : responsiveFontSize(2),
    textAlign: 'center',
    backgroundColor: 'transparent',
  },
  a: {
    fontWeight: '300',
    color: 'white', // make links coloured pink
  },
  container: {
    position: 'absolute',
    width: '95%',
    height: '85%',
    top: Platform.OS === 'ios' ? '12%' : '12%',
    marginLeft: '2.5%',
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderRadius: 25,
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    ...ifIphoneX(
      {},
      {
        top: Platform.OS === 'ios' ? 10 : 0,
      },
    ),
    justifyContent: 'center',
    alignItems: 'center',
  },

  titulo: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: responsiveFontSize(3),
  },
  textoContainerTitulo: {
    position: 'absolute',
    alignItems: 'center',
    width: '90%',
    height: '100%',
    top: '5%',
    left: '5%',
  },

  textoContainerAvisoPrivacidad: {
    position: 'absolute',
    alignItems: 'center',
    width: '90%',
    height: '100%',
    top: '25%',
    left: '5%',
  },
});
export default AvisoPrivacidad;
