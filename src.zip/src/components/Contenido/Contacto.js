import React, {Component} from 'react';
import {StyleSheet, View, Image, Text} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
export default class Contacto extends Component {
  home() {
    Actions.home();
  }

  render() {
    return (
      <View style={{flex: 1}}>
        <HeaderContenido home={this.home.bind(this)} />
        <Image
          source={require('../../images/fondoDatos.jpg')}
          style={styles.backgroundImage}
        />

        <View style={styles.textoContainerTitulo}>
          <Text style={styles.titulo}>Contacto</Text>
        </View>
        <View style={styles.textoContainer}>
          <Text style={styles.Informacion}>55 84369762</Text>
          <Text style={styles.Informacion}>info@psmutuus.com</Text>
        </View>
        <View style={styles.textoContainer2}>
          <Text style={styles.titulo2}>PROSALUD MUTUUS S.C. DE R.L.</Text>
          <Text style={styles.titulo2}>DE C.V.</Text>
          <Text style={styles.titulo2}>PALO SANTO 6 INT. 2 P.B.</Text>
          <Text style={styles.titulo2}>LOMAS ALTAS</Text>
          <Text style={styles.titulo2}>C.P. 11950, CDMX</Text>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    width: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: 30,
  },
  titulo: {
    backgroundColor: 'transparent',
    color: '#2995C3',
    marginTop: 10,
    fontSize: 35,
  },
  titulo2: {
    backgroundColor: 'transparent',
    color: '#98D17B',
    marginTop: 5,
    fontSize: 20,
  },
  Informacion: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 5,
    fontSize: 30,
  },
  textoContainerTitulo: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '10%',
  },
  textoContainer: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '25%',
  },

  textoContainerTitulo2: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '50%',
  },
  textoContainer2: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '50%',
  },
});
