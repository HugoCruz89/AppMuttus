import React from 'react';
import {Text, View, StyleSheet, Platform} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialIcons';

import {responsiveFontSize} from 'react-native-responsive-dimensions';

const ItemsBeneficiariosApi = (props) => {
  const {Nombre, SegundoNombre, ApellidoPaterno, ApellidoMaterno} = props;
  const IsNullSegundoNombre = () => {
    if (SegundoNombre === 'N/A') {
      return '';
    } else {
      return ` ${SegundoNombre}`;
    }
  };
  const nombreCompleto = `${Nombre}${IsNullSegundoNombre()} ${ApellidoPaterno} ${ApellidoMaterno}`;

  const children = (
    <Icon name="face" size={25} color="white" marginRight="5%" />
  );

  return (
    <View style={{flex: 1}}>
      <View style={styles.column}>
        {children}
        <Text style={styles.titulo2}>Nombre</Text>

        <Text style={styles.Informacion}>{nombreCompleto}</Text>

        <Text style={styles.titulo2}>Fecha de Nacimiento</Text>
        <Text style={styles.Informacion}>{props.FechaNacimiento}</Text>
        <Text style={styles.titulo2}>Genero</Text>
        {props.Genero === 'F' ? (
          <Text style={styles.Informacion}>Femenino</Text>
        ) : (
          <Text style={styles.Informacion}>Masculino</Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ColorTexto: {
    color: 'white',
    fontSize: 24,
  },
  column: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
    borderRadius: 7,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'stretch',
    paddingVertical: 0,
    backgroundColor: 'rgba(255, 255, 255, .10)',
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
    borderRadius: 7,
  },
  list: {
    marginTop: 5,
  },
  titulo2: {
    backgroundColor: 'transparent',
    color: '#98D17B',
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1) : responsiveFontSize(1.5),
  },
  Informacion: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 0,
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.3) : responsiveFontSize(1.5),
  },
});

export default ItemsBeneficiariosApi;
