import React, {useState, useEffect} from 'react';
import {StyleSheet, View, Image, Text, FlatList} from 'react-native';

import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../../Home/HeaderContenido';
import {getBeneficiarios} from '../../../api-GetBeneficiarios';
import Items from '../../Contenido/Beneficiarios/ItemsBeneficiariosApi';
import {responsiveFontSize} from 'react-native-responsive-dimensions';
const USR_STG = 'rfc';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BeneficiarioView = () => {
  const [beneficiarios, setBeneficiarios] = useState([]);
  useEffect(() => {
    async function getDatos() {
      try {
        const rfc = await AsyncStorage.getItem(USR_STG);
        getBeneficiarios(rfc).then((data) => {
          setBeneficiarios(data);
        });
      } catch (error) {}
    }
    getDatos();
  }, []);
  const home = () => {
    Actions.home();
  };

  return (
    <View style={{flex: 1}}>
      <HeaderContenido home={home.bind(this)} />
      <Image
        source={require('../../../images/fondoDatos.jpg')}
        style={styles.backgroundImage}
      />

      <View style={styles.contenedor}>
        <Text style={styles.titulo}>Beneficiarios</Text>

        {beneficiarios.length > 0 ? (
          <FlatList
            keyExtractor={(item, index) => item.RowKey}
            data={beneficiarios}
            renderItem={(itemData) => (
              <Items
                id={itemData.item.RowKey}
                Nombre={itemData.item.Nombre}
                SegundoNombre={itemData.item.SegundoNombre}
                ApellidoPaterno={itemData.item.ApellidoPaterno}
                ApellidoMaterno={itemData.item.ApellidoMaterno}
                FechaNacimiento={itemData.item.FechaNacimiento}
                Genero={itemData.item.Genero}
              />
            )}
          />
        ) : (
          <View>
            <Text style={{color: 'white'}}>¡Cargando Dependientes...!</Text>
          </View>
        )}
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  titulo: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: responsiveFontSize(3),
    paddingBottom: '7%',
  },
  contenedor: {
    position: 'absolute',
    width: '90%',
    height: '80%',
    top: '14%',
    marginLeft: '5%',
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderRadius: 25,
    alignItems: 'center',
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    width: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
export default BeneficiarioView;
