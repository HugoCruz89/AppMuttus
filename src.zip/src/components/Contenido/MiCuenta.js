import React, {Component} from 'react';
import {StyleSheet, View, Image, Text, TouchableOpacity} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
import {responsiveFontSize} from 'react-native-responsive-dimensions';
import ProgressCircle from 'react-native-progress-circle';
import {getDatosSaldo} from '../../Api-client-Saldo';

import AsyncStorage from '@react-native-async-storage/async-storage';
const USR_STG = 'rfc';

const SaldoMembresia = 'saldoMembresia';
const MEMBRESIA = 'TipoMembresia';

export default class MiCuenta extends Component {
  home() {
    Actions.pop();
  }
  constructor(props) {
    super(props);
    this.getDatos();

    this.state = {
      datos: [],
      rfc: '',
      saldo: '',
      porcentaje: '',
      saldoMembresia: '0',
      porsentaje: 0,
      tipoMembresia: '1',
    };
  }

  async almacenaSaldo(data) {
    let saldoMembresia = await AsyncStorage.getItem(SaldoMembresia);
    this.setState({
      saldo: data[0].saldo,
      porcentaje: data[0].porcentaje,
      saldoMembresia: saldoMembresia,
      p: 0,
      saldoFormato: '',
    });
    var saldo = parseInt(this.state.saldoMembresia);
    var calculoPorcentaje = (Number(this.state.saldo) * 100) / saldo;
    let p1 = String(calculoPorcentaje).substring(0, 4);
    var saldoFormat = parseFloat(Math.round(this.state.saldo * 100) / 100)
      .toFixed(2)
      .replace(/\d(?=(\d{3})+\.)/g, '$&,');
    this.setState({
      p: p1,
      porsentaje: calculoPorcentaje,
      saldoFormato: saldoFormat,
    });
  }

  async getDatos() {
    let rfc = await AsyncStorage.getItem(USR_STG);
    let tMembresia = await AsyncStorage.getItem(MEMBRESIA);
    this.state.tipoMembresia = tMembresia;
    getDatosSaldo(rfc).then((data) => {
      this.almacenaSaldo(data);
    });
  }

  llamaVistaPDFRecobra2() {
    Actions.PDFViewRecobra2();
  }

  render() {
    var porsentajeParaMostrar = this.state.porsentaje;
    return (
      <View style={{flex: 1}}>
        <HeaderContenido home={this.home.bind(this)} />
        <Image
          source={require('../../images/fondoDatos.jpg')}
          style={styles.backgroundImage}
        />
        <View style={styles.contenedor}>
          {this.state.tipoMembresia === '1' ? (
            <Text style={styles.titulo}>Mi Cuenta</Text>
          ) : (
            <Text style={styles.titulo}>Coberturas</Text>
          )}
          {this.state.tipoMembresia === '1' ? (
            <ProgressCircle
              percent={porsentajeParaMostrar}
              radius={70}
              borderWidth={25}
              color="#3399FF"
              shadowColor="#999"
              bgColor="#fff">
              <Text style={{fontSize: 22}}>{this.state.p + '%'}</Text>
            </ProgressCircle>
          ) : (
            <TouchableOpacity
              onPress={() => this.llamaVistaPDFRecobra2()}
              style={styles.buttonContainer}>
              <Text style={styles.buttonText}>Mostrar Coberturas</Text>
            </TouchableOpacity>
          )}
          {this.state.tipoMembresia == '1' ? (
            <Text style={styles.titulo2}>Suma Asegurada{'\n'}Disponible</Text>
          ) : (
            <Text></Text>
          )}
          {this.state.tipoMembresia === '1' ? (
            <Text style={styles.titulo2}>
              {'$ ' + this.state.saldoFormato + ' M/N'}
            </Text>
          ) : (
            <Text />
          )}
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',

    justifyContent: 'center',
    alignItems: 'center',
  },

  titulo: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(2.5) : responsiveFontSize(3.2),
    paddingBottom: '8%',
  },
  titulo2: {
    backgroundColor: 'transparent',
    color: '#AED43A',
    marginTop: 18,
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(2.5) : responsiveFontSize(3.2),
    textAlign: 'center',
  },
  subtitulo: {
    backgroundColor: 'transparent',
    color: '#AED43A',
    marginTop: 18,
    fontSize: 22,
  },

  titulo3: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: 18,
  },

  textoContainerTitulo: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '10%',
  },
  contenedor: {
    position: 'absolute',
    // alignItems:  'center' ,
    width: '90%',
    // height: '100%',
    height: '70%',
    top: '14%',
    marginLeft: '5%',
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderRadius: 25,
    alignItems: 'center',
  },
  buttonContainer: {
    backgroundColor: '#AED43A',
    paddingVertical: 15,
    padding: 0,
    marginBottom: 10,
    borderRadius: 8,
    width: '50%',
    height: 45,
    alignSelf: 'center',
  },
  buttonText: {
    padding: 0,
    textAlign: 'center',
    color: '#FFF',
    height: 30,
    borderRadius: 25,
    fontSize:
      Platform.OS === 'ios' ? responsiveFontSize(1.3) : responsiveFontSize(2),
  },
});
