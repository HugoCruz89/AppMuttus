import React, {Component} from 'react';
import {StyleSheet, View} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
import {responsiveFontSize} from 'react-native-responsive-dimensions';
import PDFView from 'react-native-view-pdf';

const resources = {
  url:
    'https://mutuuspro.blob.core.windows.net/imagenes/Condiciones_Generales_Multisalud_Colectivo.pdf',
};

const PDFVista = () => {
  const home = () => {
    Actions.home();
  };

  const resourceType = 'url';
  return (
    <View style={{flex: 1}}>
      <HeaderContenido home={home.bind(this)} />
      <View style={{flex: 1}}>
        <PDFView
          fadeInDuration={250.0}
          style={{flex: 1}}
          resource={resources[resourceType]}
          resourceType={resourceType}
          onLoad={() =>
            console.warn('PDF rendered from ${resourceType}', resourceType)
          }
          onError={(error) => console.warn('Cannot render PDF', error)}
        />
      </View>
    </View>
  );
};
export default PDFVista;
