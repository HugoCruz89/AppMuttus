import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  phone,
  View,
  Image,
  Text,
  Alert,
  TextInput,
  TouchableOpacity,
  FlatList,
  Keyboard,
  TouchableWithoutFeedback,
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import HeaderContenido from '../Home/HeaderContenido';
import Icon from 'react-native-vector-icons/FontAwesome';
import {responsiveFontSize} from 'react-native-responsive-dimensions';
import NavBar from '../Contenido/Diagnostico/NavBarDiagnostico';
import Input from '../Contenido/Diagnostico/InputDiagnostico';
import Items from '../Contenido/Diagnostico/ItemsDiagnostico.js';
import {showLoading, hideLoading} from 'react-native-notifyer';

import AsyncStorage from '@react-native-async-storage/async-storage';
import PathServer from '../../const/PathServer';
import {isEmail} from './../../utils';
const USR_STG = 'rfc';

const ReportaEvento = () => {
  const [diagnosticos, setDiagnosticos] = useState('');
  const [diagnosticosList, setDiagnosticosList] = useState([]);
  const [nombreMedico, setNombreMedico] = useState('');
  const [celular, setCelular] = useState('');
  const [correo, setCorreo] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const [rfc, setRfc] = useState('');
  useEffect(() => {
    getDatos();
  }, []);
  const home = () => {
    Actions.pop();
  };

  const handleRemoveItem = (id) => {
    setDiagnosticosList(diagnosticosList.filter((item) => item.id !== id));
  };

  const getDatos = async () => {
    try {
      const rfc = await AsyncStorage.getItem(USR_STG);
      setRfc(rfc);
    } catch {}
  };

  const onChangeTitle = (value) => {
    setDiagnosticos(value);
  };
  const onChangeNombreMedico = (value) => {
    setNombreMedico(value);
  };
  const onChangeCelular = (value) => {
    if (celular.length < 10) {
      setCelular(value);
    }
  };
  const onChangeCorreo = (value) => {
    setCorreo(value);
  };
  const handleAddItems = () => {
    handleModalHide();
    setDiagnosticosList((diagnosticosList) => [
      ...diagnosticosList,
      {
        id: Math.floor(Math.random() * 1000),
        diagnostico: diagnosticos,
      },
    ]);
  };
  const handleModalShow = () => {
    setIsVisible(true);
  };
  const handleModalHide = () => {
    setIsVisible(false);
  };

  const BuildArrayDiagnostic = () => {
    let newArryay = [];
    diagnosticosList.forEach((element) => {
      newArryay.push(String(element.diagnostico));
    });
    return newArryay;
  };

  const enviarCorreo = () => {
    if (!isEmail(correo)) {
      Alert.alert(
        'Error de correo',
        'Debes de ingresar una dirección de correo valida ',
        [{text: 'OK', onPress: () => null}],
        {cancelable: false},
      );
      return;
    }
    if (
      nombreMedico.length === 0 ||
      celular.length === 0 ||
      correo.length === 0 ||
      diagnosticosList.length === 0
    ) {
      Alert.alert(
        'Datos Incompletos',
        'Debes de ingresar todos los campos para poder continuar ',
        [{text: 'OK', onPress: () => null}],
        {cancelable: false},
      );
      return;
    }
    const arrayObjectives = BuildArrayDiagnostic();
    showLoading();

    return fetch(PathServer.url + 'EnvioCorreo/', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        rfc: rfc,
        nombreMedico: nombreMedico,
        Celular: celular,
        eMail: correo,
        diagnosticos: arrayObjectives,
      }),
    })
      .then((response) => {
        const {ok} = response;

        if (ok) {
          hideLoading();
          setCelular('');
          setCorreo('');
          setNombreMedico('');
          setDiagnosticos('');
          setDiagnosticosList([]);
          Alert.alert(
            'Envío de evento con éxito',
            'Se han enviado los datos correctamente ',
            [{text: 'OK', onPress: () => null}],
            {cancelable: false},
          );
        } else {
          Alert.alert(
            'Error',
            'Verifica tu conexión a internet, e intentalo nuevamente  ',
            [{text: 'OK', onPress: () => null}],
            {cancelable: false},
          );
        }
      })
      .catch((error) => {
        hideLoading();
      });
  };

  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss();
      }}>
      <View style={{flex: 1}}>
        <HeaderContenido home={home.bind(this)} />
        <Image
          source={require('../../images/fondoDatos.jpg')}
          style={styles.backgroundImage}
        />
        <View style={styles.contenedor}>
          <Text style={styles.titulo}>Reportar Evento</Text>
          <TextInput
            style={styles.input}
            underlineColorAndroid="transparent"
            value={nombreMedico}
            placeholder="Nombre Médico"
            onChangeText={onChangeNombreMedico}
            placeholderTextColor="rgba(10,10,10,0.5)"
            returnKeyType="next"
          />
          <TextInput
            style={styles.input}
            underlineColorAndroid="transparent"
            value={celular}
            placeholder="Celular"
            keyboardType={phone ? 'phone-pad' : 'numeric'}
            onChangeText={onChangeCelular}
            placeholderTextColor="rgba(10,10,10,0.5)"
            returnKeyType="next"
          />
          <TextInput
            style={styles.input}
            underlineColorAndroid="transparent"
            value={correo}
            placeholder="e-mail"
            onChangeText={onChangeCorreo}
            placeholderTextColor="rgba(10,10,10,0.5)"
            returnKeyType="next"
          />

          <NavBar openModal={handleModalShow} />
          <Input
            onChangeTitle={onChangeTitle}
            onHandleItems={handleAddItems}
            isVisible={isVisible}
            onCloseModal={handleModalHide}
          />
          {diagnosticosList.length > 0 ? (
            <FlatList
              keyExtractor={(item, index) => item.id.toString()}
              data={diagnosticosList}
              renderItem={(itemData) => (
                <Items
                  id={itemData.item.id}
                  handleRemoveItem={handleRemoveItem}
                  diagnostico={itemData.item.diagnostico}
                />
              )}
            />
          ) : null}

          <TouchableOpacity onPress={() => enviarCorreo()}>
            <View style={styles.correo}>
              <Text style={styles.title}>Reporta tu evento</Text>
              <Icon name="envelope-o" size={40} color="white" />
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};
const styles = StyleSheet.create({
  ScrollViewEstilo: {
    backgroundColor: 'red',
    height: 10,
    marginTop: 35,
  },
  titulo: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: responsiveFontSize(3),
    paddingBottom: '7%',
  },
  container: {
    backgroundColor: 'yellow',
  },
  contenedor: {
    position: 'absolute',
    // alignItems:  'center' ,
    width: '90%',
    // height: '100%',
    height: '80%',
    top: '14%',
    marginLeft: '5%',
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderRadius: 25,
    alignItems: 'center',
  },
  scroll: {
    width: '100%',
    height: '100%',
    left: '10%',
    // top: '1%',
    //alignSelf: 'center',
  },
  backgroundImage: {
    flex: 1,
    alignSelf: 'stretch',
    width: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundImage2: {
    flex: 2,
    alignSelf: 'center',
    //width: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 10,
    fontSize: responsiveFontSize(2.5),
    textAlign: 'center',
  },

  textoContainerTitulo: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '10%',
  },

  correo: {
    alignItems: 'center',
  },
  input: {
    height: 40,
    backgroundColor: 'rgba(255,255,255,0.8)',
    marginBottom: 20,
    color: '#000',
    paddingHorizontal: 15,
    width: '80%',
    borderRadius: 6,
  },

  container2: {
    position: 'absolute',
    width: '90%',
    height: '55%',
    top: '40%',
    marginLeft: '5%',
    backgroundColor: 'rgba(51, 124, 145, 0.8)',
    borderRadius: 25,
  },
  textoContainerTitulo2: {
    position: 'absolute',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    top: '7%',
  },
  column: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    backgroundColor: 'transparent',
    marginBottom: 5,
    marginHorizontal: 5,
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'stretch',
    paddingVertical: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    marginBottom: 5,
    //marginHorizontal: 5,
    paddingHorizontal: 5,
    borderRadius: 7,
    width: '80%',
  },
  list: {
    marginTop: 5,
  },
  titulo2: {
    backgroundColor: 'transparent',
    color: '#98D17B',
    fontSize: 15,
  },
  Informacion: {
    backgroundColor: 'transparent',
    color: 'white',
    marginTop: 0,
    fontSize: 15,
  },
});
export default ReportaEvento;
