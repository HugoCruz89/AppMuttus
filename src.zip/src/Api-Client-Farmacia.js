import PathServer from './const/PathServer';

function getFarmacia(rfc) {
  return fetch(PathServer.url + 'Farmacia?rfc=' + rfc)
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export {getFarmacia};
