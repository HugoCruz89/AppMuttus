import PathServer from './const/PathServer';

function getDatos(rfc) {
  return fetch(PathServer.url + 'Asociado/' + rfc)
    .then((response) => response.json())
    .then((data) => data)
    .then((datos) =>
      datos.map((data) => {
        return {
          name: data.Nombre,
          apePat: data.ApellidoPaterno,
          apeMat: data.ApellidoMaterno,
        };
      }),
    );
}

export {getDatos};
