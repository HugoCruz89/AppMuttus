import PathServer from './const/PathServer';

function getBeneficiarios(rfc) {
  return fetch(PathServer.url + 'Beneficiarios?rfc=' + rfc)
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export {getBeneficiarios};
