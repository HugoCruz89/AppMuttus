import PathServer from './const/PathServer';

function getDatosSaldo(rfc) {
  return fetch(PathServer.url + 'Saldo/' + rfc)
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export {getDatosSaldo};
