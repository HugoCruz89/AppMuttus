import PathServer from './const/PathServer';

function getDatosLogin(usuario, contrasena) {
  return fetch(
    PathServer.url + 'Seguridad?id=' + usuario + '&password=' + contrasena,
  )
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson;
    })
    .catch((error) => {});
}

export {getDatosLogin};
