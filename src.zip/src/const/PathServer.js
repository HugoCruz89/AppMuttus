export default {
  // pro
  url: 'https://mutuus-api.azurewebsites.net/api/',
  // dev:''
  //url: 'http://mutuus-dev-api.azurewebsites.net/api/',
};
