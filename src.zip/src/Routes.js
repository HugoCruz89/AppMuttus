import React, {Component} from 'react';
import {Router, Stack, Scene, StyleSheet} from 'react-native-router-flux';

import Login from './components/login/Login';
import Home from './components/Home/Home';
import ReportaEvento from './components/Contenido/ReportaEvento';
import Urgencia from './components/Contenido/Urgencia';
import Contacto from './components/Contenido/Contacto';
import MiCredencial from './components/Contenido/MiCredencial';
import MiCuenta from './components/Contenido/MiCuenta';
import AvisoPrivacidad from './components/Contenido/AvisoPrivacidad/AvisoPrivacidad';
import BeneficiarioView from './components/Contenido/Beneficiarios/BeneficiarioView';
import PDFView from './components/Contenido/PDFVista';
import PDFViewRecobra1 from './components/Contenido/PDFVistaRecobra1';
import PDFViewRecobra2 from './components/Contenido/PDFVistaRecobra2';

export default class Routes extends Component {
  render() {
    return (
      <Router>
        <Stack key="root" hideNavBar>
          <Scene key="login" component={Login} title="Login" initial={true} />
          <Scene key="home" component={Home} title="home" />
          <Scene
            key="reportaEvento"
            component={ReportaEvento}
            title="reportaEvento"
          />
          <Scene key="urgencia" component={Urgencia} title="urgencia" />
          <Scene key="contacto" component={Contacto} title="contacto" />
          <Scene
            key="miCredencial"
            component={MiCredencial}
            title="Credencial"
          />
          <Scene key="miCuenta" component={MiCuenta} title="Cuenta" />
          <Scene
            key="avisoPrivacidad"
            component={AvisoPrivacidad}
            title="AvisoPrivacidad"
          />
          <Scene
            key="beneficiarioView"
            component={BeneficiarioView}
            title="Beneficiario"
          />
          <Scene key="PDFView" component={PDFView} title="PDF" />
          <Scene
            key="PDFViewRecobra1"
            component={PDFViewRecobra1}
            title="PDF"
          />
          <Scene
            key="PDFViewRecobra2"
            component={PDFViewRecobra2}
            title="PDF"
          />
        </Stack>
      </Router>
    );
  }
}
